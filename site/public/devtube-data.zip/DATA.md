# DEV Tube data export

A curated catalogue of YouTube videos for AI / ML / AI engineering / programming / DSA / system design / job prep,
ranked by how many *independent* sources recommend each video. Hand this zip to your own coding agent
and ask for your own version (different taxonomy, scoring, UI).

## Files
- `videos.json`   final catalogue: array of video records (schema below)
- `taxonomy.json` syllabus tree: sections -> nodes (node.count = videos in the final catalogue)
- `meta.json`     build info
- `candidates.jsonl` (full pipeline output with all raw signals, per video)

## Video record (short keys)
| key | meaning |
|---|---|
| i | YouTube video id (`https://youtu.be/<i>`) |
| t / c / h | title / channel name / channel handle |
| n / s | taxonomy node id / section id |
| l | level: b=beginner i=intermediate a=advanced |
| sh | shelf life: e=evergreen s=semi-fresh f=fast-decaying |
| sc | final rank score (signal x freshness) |
| f / o | freshness 0..1 / 1 = flagged "may be outdated" |
| hn | distinct Hacker News users who linked it |
| rc | HN comments that read as recommendations |
| sr / src | number of curated sources (syllabi, GitHub lists) / their names |
| y | [first, last] year mentioned on HN |
| ag | how age was estimated: p=publish date, t=year in title, m=first HN mention (lower bound), u=unknown |
| d / p | duration seconds / publish date (only if the YouTube API enrichment step was run) |
| w | [HN comment id, short snippet] - why it was recommended. Link: `https://news.ycombinator.com/item?id=<id>` |

## Gotchas
- Age/freshness is an estimate unless `ag == "p"`.  Run `pipeline/04b_youtube_api.py` with a key for real dates/durations.
- HN data: Hugging Face `open-index/hacker-news` (ODC-By 1.0). Snippets are user comments; keep the link back to the comment.
- Thumbnails are not stored: use `https://i.ytimg.com/vi/<id>/hq2.jpg` (middle frame) or `hqdefault.jpg`.
- Videos can disappear: embedding was verified at build time via oEmbed only.
